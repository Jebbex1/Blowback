import pygame
from gamefiles import player, player_bullet
import src.gamefiles.game as game
import src.protocols.mapping.tiled_mapping as tiled_mapping
import src.protocols.mapping.rendering as rendering

if __name__ == '__main__':
    g = game.Game(1000, 1000)

    g.add_player(player.Player("Jeb", "ADMIN_66", (0, 0), 1))

    g.init_screen()
    tiled_mapping.load_to_game("src/server/maps/Test Map/Test Map.tmx", g)
    pygame.display.set_caption("Blowback (beta) testing :)")
    g.track_player(1)

    is_running = True
    while is_running:
        g.tracked_player.update_angle(g.display_scroll)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                is_running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    g.player_shoot_bullet(g.tracked_player.id, player_bullet.STANDARD_BLOWBACK)
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_i:
                    m_pos = pygame.mouse.get_pos()
                    print("player pos: {0},{1}".format(g.tracked_player.x, g.tracked_player.y))
                    print("scroll: {0},{1}".format(g.display_scroll[0], g.display_scroll[1]))
                    print("player scroll rect pos: {0},{1}".format(
                        g.tracked_player.x - g.display_scroll[0],
                        g.tracked_player.y - g.display_scroll[1]))
                    print("mouse pos: {0},{1}".format(m_pos[0], m_pos[1]))
                    print("angle: {0}".format(g.tracked_player.angle))
                    print("collision rect pos: {0},{1}".format(g.tracked_player.rect.x,
                                                               g.tracked_player.rect.y))
                    print("player count: {0}".format(len(g.players)))
                    print(f"render range: {rendering.get_near_chunks(g)}")
                    print("\n")

        g.refresh_display()

        g.clock.tick(60)
