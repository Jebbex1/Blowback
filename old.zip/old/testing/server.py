from socket import *

from src.protocols.encryption import generate_keypair
from src.protocols.transmission import recv_packet_sequence, recv_public_key, send_public_key

private_key, public_key = generate_keypair()

skt = socket(AF_INET, SOCK_STREAM)
skt.bind(("0.0.0.0", 8820))
skt.listen()
print("Server is runing and listening for connections")

client_skt, client_address = skt.accept()
print("Connected new client: {}".format(client_address))

print("Handling client")
client_key = recv_public_key(client_skt)
if client_key:
    send_public_key(client_skt, public_key)
    print("Completed key trading")
    packet = recv_packet_sequence(client_skt, private_key)
    if packet:
        print(repr(packet))

"""

        headers = (build_header("Key", rsa_key_to_string(public_key)), )
        packet = build_packet(100, headers)
        client_skt.send(packet[0] + packet[1])
        print("Sent public encryption key to client")

        

"""


client_skt.close()
print("Disconnected from client.")