from socket import socket, AF_INET, SOCK_STREAM

from src.protocols.multiplayer import *
from src.protocols.encryption import *

host_adress, port = "127.0.0.1", 8820

private_key, public_key = generate_keypair()

skt = socket(AF_INET, SOCK_STREAM)
skt.connect((host_adress, port))
print("Connected to server")

send_public_key(skt, public_key)
print("Sent public key")

is_key, server_key = recv_public_key(skt)
if is_key:
    print("Completed key trading")
    message = ("my name is inigo montoya, you killed my father, prepare to die. that is a very good quote from a "
               "movie called The Princess Bride. Another movie i like is Star Wars Episode III: Revenge of the"
               " Sith. The main plot point of that movie is that Anakin falls to the dark side." + END).encode()
    transmit_packet(skt, message, server_key)


skt.close()



