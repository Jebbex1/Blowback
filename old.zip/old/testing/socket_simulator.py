from src.protocols.multiplayer import *


def recv_packet(stream_queue: bytes) -> [bool, str]:
    length = stream_queue[:LENGTH_FIELD_SIZE].decode()
    stream_queue = stream_queue[LENGTH_FIELD_SIZE:]
    if length.isnumeric():
        length = int(length)
        packet = b""
        while length > 10:
            packet += stream_queue[:10]
            stream_queue = stream_queue[10:]
            length -= 10
        packet += stream_queue[:length]
        return True, packet.decode()
    else:
        return False, "Invalid packet"


stream = (b"000270my name is inigo montoya, you killed my father, prepare to die. that is a very good quote from a movie"
          b" called The Princess Bride. Another movie i like is Star Wars Episode III: Revenge of the Sith. The "
          b"main plot point of that movie is that Anakin falls to the dark side..")



print(len(SEPERATOR + "Heade"))