import pygame


class PseudoPlayer(pygame.sprite.Sprite):
    def __init__(self, coords: list[int], rect: pygame.Rect, angle: float):
        pygame.sprite.Sprite.__init__(self)
        self.coords = coords
        self.rect = pygame.Rect(self.coords[0], self.coords[1], rect.width, rect.height)
        self.rect.center = self.coords
        self.angle = angle

    def refresh_rect(self):
        self.rect.x = self.coords[0]
        self.rect.y = self.coords[1]
        self.rect.center = self.coords

    def copy(self):
        self.refresh_rect()
        return PseudoPlayer(self.coords, self.rect, self.angle)
