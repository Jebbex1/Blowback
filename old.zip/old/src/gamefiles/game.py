import math
import random
import time
import pygame
import threading

import src.utils.general as helpers
import src.protocols.mapping.map_data as map_data
import src.protocols.mapping.rendering as mapping_optimizations
import src.protocols.mapping.tiles.chunk as chunk
import src.gamefiles.player_bullet as player_bullet
import src.gamefiles.player as player
import src.gamefiles.pseudo_player as pseudo_player


# IMPLEMENT: Spawnpoint mechanism, for each team there will be a spawnpoint,
#   additionally, there will be a default spawnpoint for all players.


def get_rnd_coords(max_x, max_y):
    rand_x = random.randint(0, max_x)
    rand_y = random.randint(0, max_y)
    return rand_x, rand_y


class Game:
    def __init__(self, win_width, win_height, max_players=10, background_color=map_data.BACKGROUND_COLOR):
        pygame.init()
        self.win_width = win_width
        self.win_height = win_height
        self.render_distance = mapping_optimizations.get_render_distance(self.win_width, self.win_height)
        self.background_color = background_color
        self.display_scroll = [0, 0]

        self.players: pygame.sprite.Group = pygame.sprite.Group()
        self.bullets: pygame.sprite.Group = pygame.sprite.Group()

        self.ground_tiles: pygame.surface.Surface = pygame.Surface((win_width, win_height))
        self.ground_tiles.fill(background_color)
        self.surface_chunks: dict[tuple[int, int], chunk.Chunk] = {}
        self.collision_tiles: pygame.sprite.Group = pygame.sprite.Group()
        self.decoration_tiles: pygame.sprite.Group = pygame.sprite.Group()

        self.tiles: pygame.sprite.Group = pygame.sprite.Group()
        self.max_players = max_players

        self.tile_size = [50, 50]

        self.tracked_player: player.Player | None = None
        self.display = None
        self.clock = None

    def init_screen(self):
        pygame.init()
        self.display = pygame.display.set_mode((self.win_width, self.win_height))
        self.clock = pygame.time.Clock()

    def kill_screen(self):
        self.tracked_player = None
        self.display_scroll = [0, 0]
        self.display = None
        pygame.quit()

    def refresh_display(self):
        if self.tracked_player is None:
            self.tracked_player = self.players.sprites()[0]
        self.display.fill(self.background_color)
        self.display_scroll[0] += (self.tracked_player.x - self.display_scroll[0] - (self.win_width / 2))
        self.display_scroll[1] += (self.tracked_player.y - self.display_scroll[1] - (self.win_height / 2))

        pygame.sprite.groupcollide(self.bullets, self.collision_tiles, True, False)

        self.display_ground()
        self.display_bullets(self.display)
        self.display_players(self.display)
        self.display_walls()
        # self.display_decorations()

        # Update the GUI window
        pygame.display.update()

    def add_player(self, p):
        self.players.add(p)

    def remove_player(self, player_id: int):
        for player in self.players.sprites():
            if player.id == player_id:
                self.players.remove(player)

    def change_player_coords(self, player_id: int, coords: tuple[int, int] | tuple[float, float]):
        for player in self.players.sprites():
            if player.id == player_id:
                player.x = coords[0]
                player.y = coords[1]

    def change_player_angle(self, player_id: int, angle: int):
        for player in self.players.sprites():
            if player.id == player_id:
                player.angle = angle

    def change_player_color(self, player_id: int, color: str):
        for player in self.players.sprites():
            if player.id == player_id:
                if isinstance(color, str):
                    player.sprite_path = player.get_sprite_path(color)
                    player.refresh_sprite()

    def change_player_name(self, player_id: int, name: str):
        for player in self.players.sprites():
            if player.id == player_id:
                player.name = name

    def display_players(self, display):
        # display players
        for p in self.players.sprites():
            if p != self.players.sprites()[0]:
                p.display_at(display, [p.x - self.display_scroll[0], p.y - self.display_scroll[1]])
                # p.display_collision_rect(display, [p.x - self.display_scroll[0], p.y - self.display_scroll[1]])
            else:
                p.display_at(display, [p.x - self.display_scroll[0],
                                       p.y - self.display_scroll[1]])
                p.display_collision_rect(display, [p.x - self.display_scroll[0],
                                         p.y - self.display_scroll[1]])

    def display_bullets(self, display):
        # display bullets
        for bullet in self.bullets.sprites():
            bullet.display_at(display, [bullet.x - self.display_scroll[0],
                                        bullet.y - self.display_scroll[1]])

    def display_tile_group(self, group, display):
        for tile in group:
            scroll_block = tile.rect.copy()
            scroll_block.x = scroll_block.x - self.display_scroll[0]
            scroll_block.y = scroll_block.y - self.display_scroll[1]
            tile.display_at(display, scroll_block)

    def display_ground(self):
        for pos, target_chunk in self.surface_chunks.items():
            x = pos[0] * map_data.CHUNK_SIZE_IN_PIXELS
            y = pos[1] * map_data.CHUNK_SIZE_IN_PIXELS
            scroll_block = [x, y]
            scroll_block[0] = scroll_block[0] - self.display_scroll[0]
            scroll_block[1] = scroll_block[1] - self.display_scroll[1]
            self.display.blit(target_chunk, scroll_block)

        """scroll_block = self.ground_tiles.get_rect().copy()
        scroll_block.x = scroll_block.x - self.display_scroll[0]
        scroll_block.y = scroll_block.y - self.display_scroll[1]
        self.display.blit(self.ground_tiles.convert_alpha(), scroll_block)"""

    def display_walls(self):
        self.display_tile_group(self.collision_tiles, self.display)

    def display_decorations(self):
        self.display_tile_group(self.decoration_tiles, self.display)

    def is_available_id(self, id: int) -> bool:
        for player in self.players.sprites():
            if player.id == id:
                return False
        return True

    def gen_player_id(self) -> int:
        for i in range(1, self.max_players):
            if self.is_available_id(i):
                return i
        else:
            return -1

    def get_player(self, id: int) -> player.Player | None:
        for player in self.players.sprites():
            if player.id == id:
                return player
        return None

    def track_player(self, id: int):
        p = self.get_player(id)
        if p is not None:
            self.tracked_player = p

    def move_player_by_blowback(self, p: player.Player | int, blowback: int, angle: int):
        if isinstance(p, int):
            p = self.get_player(p)
        pc = pseudo_player.PseudoPlayer([p.x, p.y], p.rect, angle)
        x = math.floor(blowback * math.cos(math.radians(angle)))
        y = math.floor(blowback * math.sin(math.radians(angle)))
        for i in range(0, 100):
            time.sleep(0.0001)
            pc.coords[0] -= x / 100
            pc.coords[1] -= y / 100
            pc.refresh_rect()
            if pygame.sprite.spritecollideany(pc, self.collision_tiles):
                break
            p.x -= x / 100
            p.y -= y / 100

        # make x val to int
        pc.coords[0] = helpers.round_towards_zero(p.x)
        if pygame.sprite.spritecollideany(pc, self.collision_tiles):
            pc.coords[0] = helpers.round_away_zero(p.x)
            p.x = helpers.round_away_zero(p.x)
        else:
            p.x = helpers.round_towards_zero(p.x)

        # make y val to int
        pc.coords[1] = helpers.round_towards_zero(p.y)
        if pygame.sprite.spritecollideany(pc, self.collision_tiles):
            pc.coords[1] = helpers.round_away_zero(p.y)
            p.y = helpers.round_away_zero(p.y)
        else:
            p.y = helpers.round_towards_zero(p.y)

    def player_shoot_bullet(self, id: int, blowback: int):
        for player in self.players.sprites():
            if player.id == id:
                self.bullets.add(player_bullet.PlayerBullet(player.x, player.y, player.angle))
                threading.Thread(target=self.move_player_by_blowback,
                                 args=(player, blowback, player.angle)).start()


"""def calculate_blowback(player: PseudoPlayer | Player, tiles: pygame.sprite.Group,
                       max_blowback: tuple[int, int], step=10) -> tuple[int, int]:
    if isinstance(player, Player):
        p = PseudoPlayer([player.x, player.y], player.rect, player.angle)
    else:
        p = player.copy()

    allowed_x, allowed_y = 0, 0
    max_x = max_blowback[0]
    max_y = max_blowback[1]
    blowback_x = step * math.cos(math.radians(p.angle))
    blowback_y = step * math.sin(math.radians(p.angle))

    while True:
        p.coords[0] -= blowback_x
        p.coords[1] -= blowback_y
        p.refresh_rect()
        collides = pygame.sprite.spritecollideany(p, tiles)
        oversteps = abs(allowed_x + blowback_x) > abs(max_x) or abs(allowed_y + blowback_y) > abs(max_y)
        if collides or oversteps:
            if step > 1 and collides and not oversteps:
                p.coords[0] += blowback_x
                p.coords[1] += blowback_y
                p.refresh_rect()
                percise_blowback = calculate_blowback(p, tiles, max_blowback, step=1)
                allowed_x += percise_blowback[0]
                allowed_y += percise_blowback[1]
            break
        else:
            allowed_x += blowback_x
            allowed_y += blowback_y
    return int(allowed_x), int(allowed_y)"""


def main():

    game = Game(1000, 750)

    game.add_player(player.Player("Jeb", "ADMIN_66", (game.win_width / 2, game.win_height / 2), 1))

    game.add_player(player.Player("Puppet1", "red", get_rnd_coords(game.win_width, game.win_height), 3))
    '''
    gamefiles.add_player(Player("Puppet2", "green", get_rnd_coords(gamefiles.win_width, gamefiles.win_height)))
    gamefiles.add_player(Player("Puppet3", "blue", get_rnd_coords(gamefiles.win_width, gamefiles.win_height)))
    gamefiles.add_player(Player("Puppet4", "cyan", get_rnd_coords(gamefiles.win_width, gamefiles.win_height)))
    gamefiles.add_player(Player("Puppet5", "orange", get_rnd_coords(gamefiles.win_width, gamefiles.win_height)))
    gamefiles.add_player(Player("Puppet6", "purple", get_rnd_coords(gamefiles.win_width, gamefiles.win_height)))
    gamefiles.add_player(Player("Puppet7", "pink", get_rnd_coords(gamefiles.win_width, gamefiles.win_height)))
    gamefiles.add_player(Player("Puppet8", "yellow", get_rnd_coords(gamefiles.win_width, gamefiles.win_height)))
    '''

    pygame.display.set_caption("Blowback (beta) testing :)")
    while input() == "y":
        game.track_player(1)
        game.init_screen()

        is_running = True
        while is_running:
            game.tracked_player.update_angle(game.display_scroll)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    is_running = False
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        game.player_shoot_bullet(game.tracked_player.id, player_bullet.STANDARD_BLOWBACK)
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_i:
                        m_pos = pygame.mouse.get_pos()
                        print("player pos: {0},{1}".format(game.tracked_player.x, game.tracked_player.y))
                        print("scroll: {0},{1}".format(game.display_scroll[0], game.display_scroll[1]))
                        print("player scroll rect pos: {0},{1}".format(
                            game.tracked_player.x - game.display_scroll[0],
                            game.tracked_player.y - game.display_scroll[1]))
                        print("mouse pos: {0},{1}".format(m_pos[0], m_pos[1]))
                        print("angle: {0}".format(game.tracked_player.angle))
                        print("collision rect pos: {0},{1}".format(game.tracked_player.rect.x,
                                                                   game.tracked_player.rect.y))
                        print("player count: {0}".format(len(game.players)))
                        print("\n")
            game.refresh_display()
            game.clock.tick(60)

        game.kill_screen()

if __name__ == "__main__":
    main()
