import pygame
import math

STANDARD_BLOWBACK = 48


class PlayerBullet(pygame.sprite.Sprite):
    def __init__(self, x, y, angle, ftl=60, speed=18, size=9,
                 *groups: pygame.sprite.Group):
        super().__init__(*groups)
        self.x = x
        self.y = y

        self.speed = speed
        self.ftl = ftl
        self.size = size

        self.sprite = pygame.transform.smoothscale(pygame.image.load("assets/projectile_sprites/bullet_v0.png"),
                                                   (size, size))
        self.angle = angle-180

        self.x_vel = math.cos(math.radians(self.angle)) * self.speed
        self.y_vel = math.sin(math.radians(self.angle)) * self.speed


        self.rect = pygame.Rect(self.x, self.y, self.size, self.size)
        self.rect.center = (self.x, self.y)

    def refresh_rect(self):
        self.rect.x = self.x
        self.rect.y = self.y
        self.rect.center = (self.rect.x, self.rect.y)

    def display_collision_rect(self, display, coords):
        rect = self.rect.copy()
        rect.x = coords[0]
        rect.y = coords[1]
        rect.center = (rect.x, rect.y)
        pygame.draw.rect(display, (0, 0, 255), rect, 1)

    def natural_move(self):
        self.x -= self.x_vel
        self.y -= self.y_vel
        self.ftl -= 1
        if self.ftl <= 0:
            self.kill()

    def display_at(self, display, coords: list[2]):
        self.natural_move()

        rotated = pygame.transform.rotate(self.sprite, 180-(90 + self.angle))
        sprite_rect = rotated.get_rect(center=(coords[0], coords[1]))

        display.blit(rotated, sprite_rect)
        self.refresh_rect()

