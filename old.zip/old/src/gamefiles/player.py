import math
import pygame

DEFAULT_PLAYER_SIZE = 96
DEFAULT_HITBOX_SIZE = 54


class Player(pygame.sprite.Sprite):
    def __init__(self, name: str, color: str, start_coords: tuple[int, int] | tuple[float, float],
                 player_id: int = -1, size=DEFAULT_PLAYER_SIZE,
                 init_angle=-90):
        super().__init__()
        self.name: str = name
        self.x: int | float = start_coords[0]
        self.y: int | float = start_coords[1]
        self.size: int = size

        self.color: str = color
        self.sprite_path: str = get_sprite_path(color)
        self.sprite = pygame.transform.scale(pygame.image.load(self.sprite_path), (self.size, self.size))
        self.angle: int = init_angle

        self.id: int = player_id

        self.rect = pygame.Rect(self.x, self.y, DEFAULT_HITBOX_SIZE, DEFAULT_HITBOX_SIZE)
        self.rect.center = (self.x, self.y)

    def refresh_rect(self):
        self.rect.x, self.rect.y = self.x, self.y
        self.rect.center = (self.rect.x, self.rect.y)

    def display_collision_rect(self, display, coords):
        rect = self.rect.copy()
        rect.x = coords[0]
        rect.y = coords[1]
        rect.center = (rect.x, rect.y)
        pygame.draw.rect(display, (0, 0, 255), rect, 1)

    def display_at(self, display, coords: list[2]):
        self.refresh_rect()
        rotated = pygame.transform.rotate(self.sprite, -(90 + self.angle))
        sprite_rect = rotated.get_rect(center=(coords[0], coords[1]))
        display.blit(rotated, sprite_rect)

    def update_angle(self, rd: list[2]) -> bool:
        # rd => relative displacement
        m_pos = pygame.mouse.get_pos()
        new_angle = int(math.degrees(math.atan2(m_pos[1] - (self.y - rd[1]), m_pos[0] - (self.x - rd[0]))))
        if self.angle != new_angle:
            self.angle = new_angle
            return True
        return False

    def update_color(self, color: str):
        self.color = color
        self.sprite_path = get_sprite_path(color)

    def refresh_sprite(self):
        self.sprite = pygame.transform.smoothscale(pygame.image.load(self.sprite_path), (self.size, self.size))

    def __str__(self):
        return "Player(name={0},sprite_path={1},x={2},y={3},size={4},id={5},angle={6})".format(self.name,
                                                                                               self.sprite_path,
                                                                                               self.x,
                                                                                               self.y,
                                                                                               self.size,
                                                                                               self.id,
                                                                                               self.angle)


def get_sprite_path(color: str):
    match color.upper():
        case "RED":
            return "assets/tank_sprites/red_tank.png"
        case "BLUE":
            return "assets/tank_sprites/blue_tank.png"
        case "GREEN":
            return "assets/tank_sprites/green_tank.png"
        case "YELLOW":
            return "assets/tank_sprites/yellow_tank.png"
        case "CYAN":
            return "assets/tank_sprites/cyan_tank.png"
        case "ORANGE":
            return "assets/tank_sprites/orange_tank.png"
        case "PINK":
            return "assets/tank_sprites/pink_tank.png"
        case "PURPLE":
            return "assets/tank_sprites/purple_tank.png"
        case "ADMIN_66":
            return "assets/tank_sprites/admin_tank.png"
        case _:
            return "assets/tank_sprites/default_tank.png"
