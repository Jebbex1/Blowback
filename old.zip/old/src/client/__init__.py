import threading
import src.protocols.transmission as transmission
import src.client.client as client

if __name__ == "__main__":
    c = client.Client()
    try:
        threading.Thread(target=c.connect, args=("127.0.0.1", transmission.PORT)).start()
    except KeyboardInterrupt:
        c.send_disconnect()
        print("Program terminated")
