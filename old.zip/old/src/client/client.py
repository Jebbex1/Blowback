import socket
import pygame
import threading

import src.utils.general as helpers
import src.protocols.encryption as encryption
import src.protocols.transmission as transmission
import src.protocols.packet_builder as builder
import src.protocols.packet_analyzer as analyzer

import src.gamefiles.game as game
import src.gamefiles.player_bullet as player_bullet

# IMPLEMENT: Logging mechanism so there won't be redundent messages in the console + we would be able to save
#  events and packets to see exactly what happened that caused an error.

# IMPLEMENT: Add support for: P#001, P#100, P#102, P#304


class Client:
    def __init__(self):
        pygame.init()
        self.main_player = None
        self.private_key, self.public_key = helpers.load_keys("src/client/keys")
        self.skt = None
        self.server_public_key = None
        self.game = game.Game(500, 500)
        self.gameloop_running = True

    def connect(self, host_address: str, port: int):
        self.skt = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.skt.connect((host_address, port))
        print("Connected to server")

        print("Starting key trading process")
        transmission.send_public_key(self.skt, self.public_key)
        print("Sent public key to server")
        key = transmission.recv_public_key(self.skt)
        if key:
            print("Received public key from server")
            self.server_public_key = key
            name = input("Enter player name: ")
            color = input("Enter player color: ")
            headers = {"player-name": name, "player-color": color}
            transmission.transmit_packet_encrypted(self.skt, builder.build_packet_content("203", headers),
                                                   self.server_public_key)
            while self.gameloop_running:
                request = transmission.recv_packet_sequence(self.skt, self.private_key)
                if request is not None:
                    print()
                    print("Got {0} from server.".format(repr(request)))
                    if self.handle_packet(request) is False:
                        self.skt.close()
                        return
        else:
            print("Got invalid public key from server")
            self.skt.close()
            return

    def start_game(self):
        if self.game.tracked_player is None or self.main_player is None:
            return

        p202 = builder.build_packet_content("202", {})
        transmission.transmit_packet_encrypted(self.skt, p202, self.server_public_key)

        self.game.init_screen()
        pygame.display.set_caption("Blowback (beta) testing :)")

        while self.gameloop_running:
            if self.main_player.update_angle(self.game.display_scroll):
                packet = builder.build_packet_content("207", {"angle": str(self.main_player.angle)})
                transmission.transmit_packet_encrypted(self.skt, packet, self.server_public_key)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.gameloop_running = False
                    self.send_disconnect()

                if event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        p208_headers = {
                            "angle": self.main_player.angle,
                            "player-x": self.main_player.x,
                            "player-y": self.main_player.y,
                        }
                        packet = builder.build_packet_content("208", p208_headers)
                        transmission.transmit_packet_encrypted(self.skt, packet, self.server_public_key)
                        self.game.player_shoot_bullet(self.main_player.id, player_bullet.STANDARD_BLOWBACK)

            self.game.refresh_display()
            self.game.clock.tick(60)
        print("Game Quit.")
        pygame.quit()
        self.send_disconnect()

    def handle_packet(self, packet: str | bytes):
        if not analyzer.is_valid_packet(packet):
            return False
        if isinstance(packet, bytes):
            packet = packet.decode()
        match analyzer.get_packet_code(packet):
            case "000":
                self.handle_000_packet(packet)
            case "302":
                self.handle_302_packet(packet)
            case "303":
                self.handle_303_packet(packet)
            case "305":
                self.handle_305_packet(packet)
            case "306":
                self.handle_306_packet(packet)
            case "307":
                self.handle_307_packet(packet)
            case "308":
                self.handle_308_packet(packet)
        return True

    def handle_000_packet(self, packet: str | bytes):
        if isinstance(packet, bytes):
            packet = packet.decode()
        input_headers = analyzer.get_headers_dict(packet)
        new_key = encryption.string_to_rsa_key(input_headers["key"])
        self.server_public_key = new_key

    def handle_302_packet(self, packet: str | bytes):
        if isinstance(packet, bytes):
            packet = packet.decode()
        target = helpers.get_player_from_packet(packet)
        if target.id != self.main_player.id:
            self.game.add_player(target)

    def handle_303_packet(self, packet: str | bytes):
        if isinstance(packet, bytes):
            packet = packet.decode()
        target = helpers.get_player_from_packet(packet)
        self.game.add_player(target)
        self.game.track_player(target.id)
        self.main_player = target
        threading.Thread(target=self.start_game).start()

    def handle_305_packet(self, packet: str | bytes):
        if isinstance(packet, bytes):
            packet = packet.decode()
        self.game.add_player(helpers.get_player_from_packet(packet))

    def handle_306_packet(self, packet: str | bytes):
        if isinstance(packet, bytes):
            packet = packet.decode()
        input_headers = analyzer.get_headers_dict(packet)
        player_id = int(input_headers["player-id"])
        self.game.remove_player(player_id)

    def handle_307_packet(self, packet: str | bytes):
        if isinstance(packet, bytes):
            packet = packet.decode()
        input_headers = analyzer.get_headers_dict(packet)
        player_id = int(input_headers["player-id"])
        angle = int(input_headers["angle"])
        self.game.change_player_angle(player_id, angle)

    def handle_308_packet(self, packet: str | bytes):
        if isinstance(packet, bytes):
            packet = packet.decode()
        input_headers = analyzer.get_headers_dict(packet)
        player_id = int(input_headers["player-id"])
        angle = int(input_headers["angle"])
        player_x = float(input_headers["player-x"])
        player_y = float(input_headers["player-y"])
        blowback = int(input_headers["max-blowback"])
        self.game.change_player_angle(player_id, angle)
        self.game.change_player_coords(player_id, (player_x, player_y))
        self.game.player_shoot_bullet(player_id, blowback)

    def send_disconnect(self):
        packet = builder.build_packet_content("066", {})
        transmission.transmit_packet_encrypted(self.skt, packet, self.server_public_key)
