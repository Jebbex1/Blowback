<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="world_tileset" tilewidth="16" tileheight="16" tilecount="225" columns="15" backgroundcolor="#3c3c3c">
 <image source="../../../../assets/world_tileset.png" trans="000000" width="240" height="240"/>
</tileset>
