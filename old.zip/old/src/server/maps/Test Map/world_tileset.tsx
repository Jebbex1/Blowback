<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="world_tileset" tilewidth="16" tileheight="16" tilecount="225" columns="15">
 <image source="../../../../assets/world_tileset.png" width="240" height="240"/>
 <tile id="62" probability="0.01"/>
 <tile id="63" probability="0.02"/>
</tileset>
