import socket
from Crypto.PublicKey import RSA


class ClientInfo:
    def __init__(self,
                 skt: socket.socket,
                 ip: str,
                 public_key: RSA.RsaKey | None,
                 player_id: int = -1):

        self.skt = skt
        self.ip = ip
        self.public_key = public_key
        self.player_id = player_id

    def has_player_id(self) -> bool:
        return self.player_id != -1

    def has_public_key(self) -> bool:
        return self.public_key is not None

    def __str__(self) -> str:
        return "<ClientInfo: Player id: {id}, Socket address: {add}>".format(id=self.player_id, add=self.skt.getsockname())
