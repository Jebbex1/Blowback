import pygame
import threading

import src.protocols.transmission as transmission
import src.server.server as server

if __name__ == "__main__":
    server = server.Server("0.0.0.0", transmission.PORT, (1000, 750))
    try:
        server.crash_safe_thread(threading.Thread(target=server.start_server_socket))
        server.start_cli()

    except KeyboardInterrupt:
        server.game.is_running = False
        print("Program terminated")
    pygame.quit()