import threading
import socket as socket
import pygame
import logging

import src.utils.general as helpers
import src.utils.cl_analyzer as cl_analyzer

import src.protocols.encryption as encryption
import src.protocols.transmission as transmission
import src.protocols.packet_builder as builder
import src.protocols.packet_analyzer as analyzer

import src.server.client_info as client_info
import src.server.server_cli as server_cli

import src.gamefiles.game as game
import src.gamefiles.player as player
import src.gamefiles.player_bullet as player_bullet

SERVER_NAME = "DA BEST SERVER NAME"


def log_packet_transmission(client: client_info.ClientInfo, packet: bytes | str):
    logging.info("Sending packet to client. Client: {}, Packet: {}".format(client, repr(packet)))


def crash_safe_thread(thread: threading.Thread):
    # FIXME: This doesn't work because when the thread is started successfully, but the catch clause doen't follow
    #  the thread after it starts.
    try:
        thread.start()
    except Exception as e:
        logging.error("{e} has occurred in {t}".format(e=e, t=thread))


class Server:
    def __init__(self, host: str, port: int, game_win_size: tuple[int, int]):
        self.host = host
        self.port = port

        self.private_key, self.public_key = helpers.load_keys("src/server/keys")

        self.skt = None

        self.game = game.Game(game_win_size[0], game_win_size[1])
        self.is_running = True
        self.displayloop_running = False

        self.clients: set[client_info.ClientInfo] = set()

        self.main_player = None
        self.commands = server_cli.COMMANDS

        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s.%(msecs)05d [%(levelname)s] %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S',
            filename='src/server/logs/server log {time}.log'.format(time=helpers.get_time()),
        )
        logging.info("Server was initialized.")

    def start_server_socket(self):
        """
        Initializes the server's socket, binds it, and starts the listening loop.
        When the listening loop is stopped, the server closes.
        :returns: None
        """
        self.skt = socket.socket(transmission.SOCKET_FAMILY_STANDARD, transmission.SOCKET_TYPE_STANDARD)
        self.skt.bind((self.host, self.port))
        self.skt.listen()
        logging.info("Server socket was initialized, listening loop started.")

        while self.is_running:
            client_skt, client_address = self.skt.accept()
            new_client = client_info.ClientInfo(client_skt, client_address, None)
            self.clients.add(new_client)
            logging.info("Connected new client from ip: {}".format(client_address))
            crash_safe_thread(threading.Thread(target=self.threaded_client_handler, args=(new_client,)))

        self.skt.close()
        logging.info("Server socket was closed.")

    def threaded_client_handler(self, client: client_info.ClientInfo):
        """
        Handles a singular given client, receives packets constantly and responds accordingly.
        If an error occurs, the client is disconnected and the thread is terminated.
        :param client: The given client.
        :returns: None
        """
        logging.info("Key trading process started with client: {}".format(client))
        try:
            key = transmission.recv_public_key(client.skt)
        except transmission.SOCKET_ERRORS:
            self.disconnect_socket(client)
            return
        if key:
            logging.info("Received valid key from client: {}".format(client))
            client.public_key = key
            try:
                transmission.send_public_key(client.skt, self.public_key)
            except transmission.SOCKET_ERRORS:
                self.disconnect_socket(client)
                return
            logging.info("Key sent to client: {}".format(client))
            logging.info("Key trading process completed.")

            while self.is_running:
                try:
                    request = transmission.recv_packet_sequence(client.skt, self.private_key)
                except transmission.SOCKET_ERRORS + OSError:
                    self.disconnect_socket(client)
                    return
                if request is not None:
                    if self.handle_packet(request, client) is False:
                        return

        else:
            logging.info("Received invalid key from client: {}".format(client))

        self.disconnect_socket(client)

    def handle_packet(self, packet: str | bytes, client: client_info.ClientInfo) -> bool:
        """
        Handles a singular given packet.
        Checks if the packet follows standard protocol, if it does, the function responds
        accordingly. If not, disconnects the client.
        If an error occurs, the client is disconnected.
        :param packet: The given packet.
        :param client: The given client.
        :returns: A bool which states should the connection be maintained or stopped.
        """
        if isinstance(packet, bytes):
            packet = packet.decode()
        if not (analyzer.is_valid_packet(packet) and analyzer.is_valid_client_packet_code(
                analyzer.get_packet_code(packet))):
            self.send_error_packet(client, "400", "")
            return False
        match analyzer.get_packet_code(packet):
            case "066":
                logging.info("Received valid P#066 packet from Client: {}, Packet: {}".format(client, repr(packet)))
                self.handle_066_packet(client)
                return False
            case "202":
                logging.info("Received valid P#202 packet from Client: {}, Packet: {}".format(client, repr(packet)))
                self.handle_202_packet(client)
                return True
            case "203":
                logging.info("Received valid P#203 packet from Client: {}, Packet: {}".format(client, repr(packet)))
                self.handle_203_packet(packet, client)
                return True
            case "207":
                logging.info("Received valid P#207 packet from Client: {}, Packet: {}".format(client, repr(packet)))
                self.handle_207_packet(packet, client)
                return True
            case "208":
                logging.info("Received valid P#208 packet from Client: {}, Packet: {}".format(client, repr(packet)))
                self.handle_208_packet(packet, client)
                return True
            case _:
                logging.warning("Received valid packet from client, but it requests an unimplemented functionality. "
                                "Client: {}, Packet: {}".format(client, repr(packet)))
                self.send_error_packet(client, "501", "")
                return True

    def start_game(self):
        """
        Lets the server join the gamefiles, opens a gamefiles window.
        Runs on custom controls and inputs, can be customized and modified.
        Notifies all players that actions are performed accordingly.
        When the window closes, a P#306 is sent.
        The packets are indistinguishable from packets sent due to another players actions.
        :returns: None
        """
        if self.main_player is None:
            logging.warning("The main player isn't initialized before the gamefiles window was started.")

        self.displayloop_running = True

        self.game.init_screen()
        pygame.display.set_caption("Blowback Testing (Server-side)")

        logging.info("Game window started, joined gamefiles.")

        while self.displayloop_running:
            self.self_update_angle()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.displayloop_running = False
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        self.self_shoot_bullet()

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_i:
                        m_pos = pygame.mouse.get_pos()
                        print("player pos: {0},{1}".format(self.main_player.x, self.main_player.y))
                        print("scroll: {0},{1}".format(self.game.display_scroll[0], self.game.display_scroll[1]))
                        print("player scroll rect pos: {0},{1}".format(
                            self.main_player.x - self.game.display_scroll[0],
                            self.main_player.y - self.game.display_scroll[1]))
                        print("mouse pos: {0},{1}".format(m_pos[0], m_pos[1]))
                        print("angle: {0}".format(self.main_player.angle))
                        print("collision rect pos: {0},{1}".format(self.main_player.rect.x,
                                                                   self.main_player.rect.y))
                        print("player count: {0}".format(len(self.game.players)))
                        print("\n")
                    if event.key == pygame.K_TAB:
                        self.print_current_players()

            self.game.refresh_display()
            self.game.clock.tick(60)

        self.game.kill_screen()
        self.leave_game()

        logging.info("Game window closed, left gamefiles.")

    def print_current_players(self):
        """
        Prints current players.
        :returns: None
        """
        print("Current players ({p} players): ".format(p=len(self.game.players)))
        for player in self.game.players.sprites():
            print(player.__str__())

    def send_all(self, packet: bytes | str):
        """
        Sends all connected clients a singular given packet.
        :param packet: The given packet.
        :returns: None
        """
        if isinstance(packet, str):
            packet = packet.encode()

        for client in self.clients:
            self.send_packet(client, packet)

    def send_all_but(self, packet: bytes | str, excluded_clients: list[client_info.ClientInfo] | None):
        """
        Sends a singular given packet to all connected clients but the given excluded clients.
        :param packet: The given packet.
        :param excluded_clients: The given list of excluded clients.
        :returns: None
        """
        if isinstance(packet, str):
            packet = packet.encode()
        if excluded_clients is not None and len(excluded_clients) > 0:
            for client in self.clients:
                if client not in excluded_clients:
                    try:
                        log_packet_transmission(client, packet)
                        transmission.transmit_packet_encrypted(client.skt, packet, client.public_key)
                    except transmission.SOCKET_ERRORS:
                        self.disconnect_socket(client)
        else:
            self.send_all(packet)

    def is_accepting_new_player(self, new_client: client_info.ClientInfo) -> bool:
        """
        Checks if the server is accepting new players, and if there is a connection to the same address but through a
        different socket.
        :param new_client: The given new client
        :returns: A bool which states if the server is accepting new players.
        """
        if not (self.game.max_players > len(self.game.players.sprites())):
            return False
        for client in self.clients:
            if client.ip == new_client.ip and client != new_client:
                return False
        return True

    def self_update_angle(self):
        """
        Updates the servers players angle, and sends a P#307 packet to all clients accordingly.
        :returns: None
        """
        if self.main_player.update_angle(self.game.display_scroll):
            headers = {
                "player-id": self.main_player.id,
                "angle": self.main_player.angle,
            }
            self.send_all(builder.build_packet_content("307", headers))

    def self_shoot_bullet(self):
        """
        Shoots a bullet from the servers player, and sends an P#308 packet to all clients accordingly.
        :return:
        """
        blowback = player_bullet.STANDARD_BLOWBACK
        self.game.player_shoot_bullet(self.main_player.id, blowback)
        headers = {
            "player-id": self.main_player.id,
            "angle": self.main_player.angle,
            "player-x": self.main_player.x,
            "player-y": self.main_player.y,
            "max-blowback": blowback,
        }
        self.send_all(builder.build_packet_content("308", headers))

    def teleport_player(self, id: int, x: int, y: int):
        """
        Teleports a player with a given id, to a given location. Sends a P#101 packet accordingly.
        :param id: The given players' id.
        :param x: The given x coordinate.
        :param y: The given y coordinate.
        :return:
        """
        self.game.change_player_coords(id, (x, y))
        headers = {
            "player-id": id,
            "player-new-x": x,
            "player-new-y": y,
        }
        p101 = builder.build_packet_content("101", headers)
        self.send_all(p101)

    def handle_066_packet(self, client: client_info.ClientInfo):
        """
        Handles a 066 request from a given client.
        :param client: The given client.
        :returns: None
        """
        self.disconnect_socket(client)

    def handle_202_packet(self, client: client_info.ClientInfo):
        """
        Handles a P#202 request. Send all current players to a given client.
        :param client: The given client.
        :return:
        """
        logging.info("Sending all the current players to client. Client: {c}".format(c=client))
        for p in self.game.players.sprites():
            p302 = builder.build_packet_content("302", helpers.packet_headers_from_player(p))
            self.send_packet(client, p302)

    def handle_203_packet(self, packet: str | bytes, client: client_info.ClientInfo):
        """
        Handles a given P#203 packet, checks if the gamefiles is accepting new players, responds accordingly and sends a
        corresponding packet to all other players.
        :param packet: The given packet.
        :param client: The given client who wants to join the gamefiles.
        :returns: None
        """
        if not self.is_accepting_new_player(client):
            p305 = builder.build_packet_content("304", {},
                                                "Game is not accepting new players at the moment.")
            self.send_packet(client, p305)
            return

        input_headers = analyzer.get_headers_dict(packet)
        player_name = input_headers["player-name"]
        player_color = input_headers["player-color"]
        player_id = int(self.game.gen_player_id())
        player_x, player_y = game.get_rnd_coords(self.game.win_width, self.game.win_height)
        player_size = player.DEFAULT_PLAYER_SIZE

        # add player to the gamefiles:
        client.player_id = player_id
        self.game.add_player(player.Player(player_name, player_color, (player_x, player_y), player_id))

        headers = {
            "player-name": player_name,
            "player-x": player_x,
            "player-y": player_y,
            "player-id": player_id,
            "player-color": player_color,
            "player-size": player_size,
        }
        p303 = builder.build_packet_content("303", headers)
        p305 = builder.build_packet_content("305", headers)
        self.send_packet(client, p303)
        self.send_all_but(p305, [client])

    def handle_207_packet(self, packet: str | bytes, client: client_info.ClientInfo):
        """
        Handles a given P#207 packet. Updates the gamefiles, and sends a corresponding P#307 to all relevant players.
        :param packet: The given packet.
        :param client: The given client who sent the packet.
        :returns: None
        """
        if isinstance(packet, bytes):
            packet = packet.decode()
        player_id = client.player_id
        if player_id == -1:
            self.send_error_packet(client, "401", "You don't have a player in the gamefiles.")
            return
        try:
            input_headers = analyzer.get_headers_dict(packet)
            angle = int(input_headers["angle"])
            if not -180 <= angle <= 180:
                angle = helpers.single_rotation_angle(angle)
        except ValueError:
            self.send_error_packet(client, "402", "Angle must be an integer.")
            return
        
        self.change_player_angle(player_id, angle)
        
        headers = {
            "player-id": player_id,
            "angle": angle,
        }
        p307 = builder.build_packet_content("307", headers)
        self.send_all_but(p307, [client])

    def handle_208_packet(self, packet: str | bytes, client: client_info.ClientInfo):
        """
        Handles P#208 packet. Sends a corresponding P#308 to all relevant players if needed, and responds to the given
        client if needed.
        :param packet: The given packet.
        :param client: The given client who sent the packet.
        :returns: None
        """
        player_id = client.player_id
        if player_id == -1:
            self.send_error_packet(client, "401", "You don't have a player in the gamefiles.")
            return
        try:
            input_headers = analyzer.get_headers_dict(packet)
            target = self.game.get_player(player_id)
            angle = int(input_headers["angle"])
            px = float(input_headers["player-x"])
            py = float(input_headers["player-y"])
            if not -180 <= angle <= 180:
                angle = helpers.single_rotation_angle(angle)
        except ValueError:
            self.send_error_packet(client, "402", "Parameter for angle must be an integer.")
            return

        blowback = player_bullet.STANDARD_BLOWBACK
        self.change_player_coords(player_id, (px, py))
        self.change_player_angle(player_id, angle)
        self.player_shoot_bullet(player_id, blowback)

        headers = {
            "player-id": player_id,
            "angle": angle,
            "player-x": target.x,
            "player-y": target.y,
            "max-blowback": blowback,
        }
        p308 = builder.build_packet_content("308", headers)
        self.send_all_but(p308, [client])

    def send_error_packet(self, client: client_info.ClientInfo, code: int | str, body: str):
        logging.warning("An unexpected error triggered an error packet to be sent to a client. "
                        "Client: {client}, Packet error code: {code}, Packet body: {body}"
                        .format(client=client, code=code, body=body))
        error_packet = builder.build_packet_content(str(code), {}, body)
        self.send_packet(client, error_packet)

    def disconnect_socket(self, client: client_info.ClientInfo):
        """
        Disconnects the client, removes from the clients set, and removes their player from the gamefiles, and send a
        corresponding P#306 packet to all other players.
        :param client: The given client.
        :returns: None
        """
        self.game.remove_player(client.player_id)
        self.clients.remove(client)
        p306 = builder.build_packet_content("306", {"player-id": client.player_id})
        self.send_all_but(p306, [client])
        try:
            client.skt.close()
        finally:
            return

    def print_clients(self):
        """
        Prints the connected clients.
        :returns: None
        """
        print("There are {n} clients connected:".format(n=len(self.clients)))
        for client in self.clients:
            print(client.__str__())

    def join_game(self, cmd: dict):
        """
        Joins the gamefiles, extracts player data from a given dictionary of parameters, updates the gamefiles, and sends
        corresponding P#305 packet to all connected clients. Creates a new thread that manages the gamefiles window.
        :param cmd: The given dictionary that contains all the player data.
        :returns: None
        """
        player_name = cmd["playername"]
        player_color = cmd["playercolor"]
        player_x = cmd["playerx"]
        player_y = cmd["playery"]
        player_id = self.game.gen_player_id()
        player_size = player.DEFAULT_PLAYER_SIZE
        new_player = player.Player(player_name, player_color, (player_x, player_y), player_id, player_size)

        self.game.add_player(new_player)
        self.game.track_player(new_player.id)
        self.main_player = new_player
        crash_safe_thread(threading.Thread(target=self.start_game, args=()))

        headers = {
            "player-name": player_name,
            "player-x": player_x,
            "player-y": player_y,
            "player-id": player_id,
            "player-color": player_color,
            "player-size": player_size,
        }
        p305 = builder.build_packet_content("305", headers)
        self.send_all(p305)

    def leave_game(self):
        """
        Leaves the gamefiles, updates the gamefiles, and send the corresponding P#306 packet to all connected clients.
        :returns: None
        """
        id = self.main_player.id
        self.game.remove_player(id)
        self.main_player = None
        p306 = builder.build_packet_content("306", {"player-id": id})
        self.send_all(p306)

    def run_command(self, command: str):
        """
        Runs a command. Extracts command and parameters from a given single line command, and matches it to a command
        dictionary attribute of a server.
        :param command: The given single line command
        :returns: None
        """
        cmd = cl_analyzer.parse_command(self.commands, command)
        if cl_analyzer.ERROR_KEY in cmd.keys():
            print("An Error has occurred: {e}".format(e=cmd[cl_analyzer.ERROR_KEY]))
            return
        if cl_analyzer.HELP_KEY in cmd.keys():
            print(cmd[cl_analyzer.HELP_KEY])
            return
        match cmd[cl_analyzer.COMMAND_KEY]:
            case "joingame":
                if self.displayloop_running:
                    print("Can't join the gamefiles: You are already in the gamefiles.")
                else:
                    self.join_game(cmd)
            case "leavegame":
                self.displayloop_running = False
            case "players":
                self.print_current_players()
            case "teleport":
                self.teleport_player(cmd["playerid"], cmd["playerx"], cmd["playery"])
            case "clients":
                self.print_clients()
            case "regenkeys":
                self.regen_keys()

    def start_cli(self):
        """
        Starts the Command-Line-Interface processing of the server.
        :returns: None
        """
        while self.is_running:
            command = input()
            self.run_command(command)

    def send_packet(self, client: client_info.ClientInfo, packet: bytes | str):
        try:
            log_packet_transmission(client, packet)
            transmission.transmit_packet_encrypted(client.skt, packet, client.public_key)
        except transmission.SOCKET_ERRORS:
            self.disconnect_socket(client)

    def regen_keys(self):
        # FIXME: There's a mismatch between the keys when switching them out.
        self.private_key, self.public_key = helpers.generate_key_files("src/server/keys")
        headers = {"key": encryption.rsa_key_to_string(self.public_key)}
        p000 = builder.build_packet_content("000", headers)
        self.send_all(p000)
        
    def change_player_angle(self, player_id: int, angle: int):
        logging.info("Changing a player's angle. Player id: {p}, New angle: {n}".format(p=player_id, n=angle))
        self.game.change_player_angle(player_id, angle)
    
    def change_player_coords(self, player_id: int, coords: tuple[int, int] | tuple[float, float]):
        logging.info("Changing a player's position. Player id: {p}, New position: {x},{y}"
                     .format(p=player_id, x=coords[0], y=coords[1]))
        self.game.change_player_coords(player_id, coords)
        
    def player_shoot_bullet(self, player_id: int, blowback: int):
        logging.info("Triggering a player to shoot a bullet. Player id: {p}, Blowback: {b}"
                     .format(p=player_id, b=blowback))
        self.game.player_shoot_bullet(player_id, blowback)

