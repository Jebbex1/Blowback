COMMANDS = {
    "joingame": [
        "/joingame <playername> <playercolor> <playerx> <playery>",
        ("playername",  r"\w"),
        ("playercolor", r"\w"),
        ("playerx",     r"[-0-9]"),
        ("playery",     r"[-0-9]"),
    ],

    "leavegame": [
        "/leavegame"
    ],

    "teleport": [
        "/teleport <playerid> <playerx> <playery>",
        ("playerid",    r"[-0-9]"),
        ("playerx",     r"[-0-9]"),
        ("playery",     r"[-0-9]"),
    ],

    "players": [
        "/players",
    ],

    "clients": [
        "/clients",
    ],

    "regenkeys": [
        "/regenkeys",
    ]
}
