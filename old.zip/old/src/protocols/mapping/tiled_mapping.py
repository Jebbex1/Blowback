
import pygame
from pytmx.util_pygame import load_pygame

import src.protocols.mapping.map_data as map_data
import src.protocols.mapping.tiles.tile as collision_tile
import src.protocols.mapping.tiles.chunk as chunk
import src.utils.general as helpers
import src.gamefiles.game as game


def load_to_game(tmx_path: str, target_game: game.Game):
    tmx_data = load_pygame(tmx_path)
    for layer in tmx_data.visible_layers:
        if hasattr(layer, 'data'):
            match layer.name.split(' ')[0]:
                case map_data.MAP_COLLISION_TILE_IDENTIFIER:
                    for x, y, surf in layer.tiles():
                        pos = (x * map_data.TILE_SIZE, y * map_data.TILE_SIZE)
                        collision_tile.StandardTile(pos=pos, surface=surf,
                                                    groups=target_game.collision_tiles, has_collision=True)
                case map_data.MAP_GROUND_TILE_IDENTIFIER:
                    for x, y, surf in layer.tiles():
                        surf = pygame.transform.scale(surf, (map_data.TILE_SIZE, map_data.TILE_SIZE))
                        pos = (x * map_data.TILE_SIZE, y * map_data.TILE_SIZE)
                        load_surface_to_matching_chunk(pos, surf, target_game)

                case map_data.MAP_DECORATION_TILE_IDENTIFIER:
                    for x, y, surf in layer.tiles():
                        pos = (x * map_data.TILE_SIZE, y * map_data.TILE_SIZE)
                        collision_tile.StandardTile(pos=pos, surface=surf,
                                                    groups=target_game.decoration_tiles, has_collision=False)


def load_surface_to_matching_chunk(pos, surf, target_game: game.Game):
    chunk_x = helpers.get_matching_chunk(pos[0])
    rel_x = helpers.get_relative_pos(chunk_x, pos[0])

    chunk_y = helpers.get_matching_chunk(pos[1])
    rel_y = helpers.get_relative_pos(chunk_y, pos[1])

    if (chunk_x, chunk_y) not in target_game.surface_chunks:
        target_game.surface_chunks[chunk_x, chunk_y] = chunk.Chunk(map_data.CHUNK_SIZE_IN_PIXELS,
                                                                   map_data.BACKGROUND_COLOR)
    target_chunk = target_game.surface_chunks[chunk_x, chunk_y]
    target_chunk.blit(surf, (rel_x, rel_y))

