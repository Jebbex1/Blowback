import pygame
import protocols.mapping.map_data as map_data


class StandardTile(pygame.sprite.Sprite):
    def __init__(self, pos: tuple[int, int], surface: pygame.Surface, groups: pygame.sprite.Group,
                 has_collision: bool, size: int = map_data.TILE_SIZE):
        super().__init__(groups)
        self.x = pos[0]
        self.y = pos[1]

        if has_collision:
            self.rect = pygame.Rect(self.x, self.y, size, size)
        else:
            self.rect = pygame.Rect(self.x, self.y, 0, 0)

        self.image = pygame.transform.scale(surface, (size, size))

    def display_at(self, display, scroll_block):
        display.blit(self.image, scroll_block)

    def display_collision_rect(self, display, coords):
        rect = self.rect.copy()
        rect.x = coords[0]
        rect.y = coords[1]
        pygame.draw.rect(display, (255, 255, 0), rect, 1)