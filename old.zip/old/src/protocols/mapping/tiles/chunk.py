import pygame


class Chunk(pygame.surface.Surface):
    def __init__(self, size_pixels: int, background_color: tuple[int, int, int, int] | str):
        pygame.surface.Surface.__init__(self, (size_pixels, size_pixels))
        self.size_pixels = size_pixels
        self.background_color = background_color
        self.fill(background_color)


    def display_at(self, display, scroll_block):
        display.blit(self, scroll_block)

    def display_collision_rect(self, display, coords):
        rect = self.border_rect.copy()
        rect.x = coords[0]
        rect.y = coords[1]
        pygame.draw.rect(display, (100, 100, 100), rect, 1)

