import math
import src.protocols.mapping.map_data as map_data
import src.protocols.mapping.tiles.chunk as chunk
import src.protocols.mapping.tiled_mapping as mapping


def get_render_distance(win_width, win_height) -> tuple[int, int]:
    rdx = render_distance(win_width)
    rdy = render_distance(win_height)
    return rdx, rdy


def render_distance(length) -> int:
    return math.floor(length/map_data.CHUNK_SIZE_IN_PIXELS)


def get_near_chunks(player_pos: tuple[int, int], render_distance: tuple[int, int]):
    player_chunk_pos = (mapping.get_matching_chunk(player_pos[0]),
                        mapping.get_matching_chunk(player_pos[1]))
    rx = range(player_chunk_pos[0] - render_distance[0], player_chunk_pos[0] + render_distance[0])
    ry = range(player_chunk_pos[0] - render_distance[1], player_chunk_pos[0] + render_distance[1])
    return rx, ry
