from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA

import utils.general as helpers

CHUNK_LENGTH = 128


def generate_keypair(private_key_len: int = 2048) -> tuple[RSA.RsaKey, RSA.RsaKey]:
    private_key = RSA.generate(private_key_len)
    public_key = private_key.publickey()
    return private_key, public_key


def rsa_key_to_string(key: RSA.RsaKey) -> str:
    return key.exportKey().decode()


def string_to_rsa_key(key_string: str):
    return RSA.importKey(key_string)


def encrypt(content: bytes | str, public_key: RSA.RsaKey) -> bytes:
    cipher = PKCS1_OAEP.new(key=public_key)
    if isinstance(content, str):
        return cipher.encrypt(content.encode())
    return cipher.encrypt(content)


def decrypt(encrypted_content: bytes | str, private_key: RSA.RsaKey) -> str:
    cipher = PKCS1_OAEP.new(key=private_key)
    if isinstance(encrypted_content, str):
        return cipher.decrypt(encrypted_content.encode()).decode()
    return cipher.decrypt(encrypted_content).decode()


def devide_into_encryptable_segments(content: bytes | str) -> list[bytes]:
    if isinstance(content, str):
        content = content.encode()
    return helpers.fixed_len_bytes_list(content, CHUNK_LENGTH)


def encrypt_segments(segments: list[bytes], public_key: RSA.RsaKey) -> list[bytes]:
    encrypted = []
    for segment in segments:
        encrypted.append(encrypt(segment, public_key))
    return encrypted


if __name__ == "__main__":
    pr, pu = generate_keypair()
    """message = (b"my name is inigo montoya, you killed my father, prepare to die. that is a very good quote from a movie"
               b" called The Princess Bride. Another movie i like is Star Wars Episode III: Revenge of the Sith. The "
               b"main plot point of that movie is that Anakin falls to the dark side.")
    print(len(message))"""

    print(rsa_key_to_string(pu))
    pu = string_to_rsa_key(rsa_key_to_string(pu))
    print(rsa_key_to_string(pu))


