import math
import os
import re
from socket import socket

import numpy as np
from Crypto.PublicKey import RSA
import datetime

import src.protocols.encryption as encryption
import src.protocols.packet_analyzer as analyzer
import src.gamefiles.player as player
import src.protocols.mapping.map_data as map_data


def round_away_zero(x: int):
    a = np.abs(x)
    b = np.floor(a) + np.floor(2 * (a % 1))
    return np.sign(x) * b


def round_towards_zero(x: int):
    return np.fix(x)


def fixed_len_bytes_list(content: bytes | str, chunk_length: int) -> list[bytes]:
    if isinstance(content, str):
        content = content.encode()
    return list(content[0 + i:chunk_length + i] for i in range(0, len(content), chunk_length))


def is_folder(folder_path: str) -> bool:
    return os.path.isdir(folder_path)


def is_file(file_path: str) -> bool:
    return os.path.isfile(file_path)


def single_rotation_angle(angle: int) -> int:
    if angle < 0:
        return angle % 180 - 180
    else:
        return angle % 180


def sock_ip(skt: socket):
    return skt.getsockname()[0]


def chars_fit_regex(target: str, regex: str) -> bool:
    regex = regex + r'{' + str(len(target)) + r'}'
    pattern = re.compile(regex)
    return isinstance(pattern.match(target), re.Match)


def collect_user_input_by_regex(prompt: str, regex: str) -> str:
    valid = False
    user_input = ''
    while not valid:
        user_input = input(prompt)
        valid = chars_fit_regex(user_input, regex)
    return user_input


def has_key(dic: dict, key: str) -> bool:
    return key in dic.keys()


def load_keys(key_dir_path: str) -> tuple[RSA.RsaKey, RSA.RsaKey]:
    if not is_folder(key_dir_path):
        os.mkdir(key_dir_path)
    if (is_file("{p}/private_key.pem".format(p=key_dir_path)) and
            is_file("{p}/public_key.pem".format(p=key_dir_path))):
        return read_key_files(key_dir_path)
    else:
        return generate_key_files(key_dir_path)


def generate_key_files(key_dir_path: str) -> tuple[RSA.RsaKey, RSA.RsaKey]:
    pr_key, pu_key = encryption.generate_keypair()
    prk_file = open("{p}/private_key.pem".format(p=key_dir_path), "wb")
    prk_file.flush()
    prk_file.write(encryption.rsa_key_to_string(pr_key).encode())
    puk_file = open("{p}/public_key.pem".format(p=key_dir_path), "wb")
    puk_file.flush()
    puk_file.write(encryption.rsa_key_to_string(pu_key).encode())

    prk_file.close()
    puk_file.close()
    return pr_key, pu_key


def read_key_files(key_dir_path: str) -> tuple[RSA.RsaKey, RSA.RsaKey]:
    prk_file = open("{p}/private_key.pem".format(p=key_dir_path), "rb")
    puk_file = open("{p}/public_key.pem".format(p=key_dir_path), "rb")
    pr_key = encryption.string_to_rsa_key(prk_file.read().decode())
    pu_key = encryption.string_to_rsa_key(puk_file.read().decode())

    prk_file.close()
    puk_file.close()
    return pr_key, pu_key


def get_player_from_packet(packet: str | bytes) -> player.Player:
    if isinstance(packet, bytes):
        packet = packet.decode()
    input_headers = analyzer.get_headers_dict(packet)
    player_name = input_headers["player-name"]
    player_x = float(input_headers["player-x"])
    player_y = float(input_headers["player-y"])
    player_id = int(input_headers["player-id"])
    player_color = input_headers["player-color"]
    player_size = int(input_headers["player-size"])
    return player.Player(player_name, player_color, (player_x, player_y),
                  player_id=player_id, size=player_size)


def packet_headers_from_player(p: player.Player) -> dict[str, str | int | float]:
    return {
        "player-name": p.name,
        "player-x": p.x,
        "player-y": p.y,
        "player-id": p.id,
        "player-color": p.color,
        "player-size": p.size,
    }


def get_time(format: str = "%Y-%m-%d %H-%M-%S"):
    return datetime.datetime.now().strftime(format)


def get_matching_chunk(pos: int):
    return math.floor(pos / map_data.CHUNK_SIZE_IN_PIXELS)


def get_relative_pos(chunk_num: int, absolute_pos: int):
    return absolute_pos - (chunk_num * map_data.CHUNK_SIZE_IN_PIXELS)
