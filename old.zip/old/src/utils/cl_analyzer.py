import src.utils.general as utils

ERROR_KEY = "Error"
HELP_KEY = "Help"
COMMAND_KEY = "Command"


def get_valid_cmd(commands: dict, line: str) -> str | None:
    line = line.strip().split(" ")[0]
    if line.startswith("/"):
        line = line[1:]
        if line in commands.keys():
            return line
    return None


def get_help_dialog(commands: dict, command: str) -> str | None:
    help_line = commands[command][0]
    return help_line if isinstance(help_line, str) else None


def parse_parameters(expected_params, passed_params) -> dict:
    final_params = {}
    for i in range(0, len(expected_params)):
        p_name, regex = expected_params[i]
        if not utils.chars_fit_regex(passed_params[i], regex):
            return {ERROR_KEY: "Parameter '{p}' does not match regex: '{r}'.".format(p=p_name, r=regex)}
        match regex:
            case r"\w":
                final_params[p_name] = str(passed_params[i])
            case r"[-0-9]":
                final_params[p_name] = int(passed_params[i])
            case _:
                return {
                    ERROR_KEY: "Regex '{r}' for param '{p}' doesn't have a casting predefined."
                    .format(p=p_name, r=regex)
                }
    return final_params


def parse_command(commands: dict, line: str) -> dict[str, str | int]:
    command = get_valid_cmd(commands, line)

    if command is None:
        return {ERROR_KEY: "Command not found."}

    passed_params = line.strip().split(" ")[1:]
    expected_params = commands[command][1:]

    if len(passed_params) == 1 and passed_params[0] == "?":
        help_line = get_help_dialog(commands, command)
        if help_line is None:
            return {ERROR_KEY: "Help dialog for command '{h}' not found.".format(h=command)}
        return {HELP_KEY: help_line}

    if len(passed_params) != len(expected_params):
        return {
            ERROR_KEY: "Number of passed params does not match the number of expected params. Expected: {e}, Got: {g}"
            .format(e=len(commands[command]), g=len(passed_params))
        }

    params = parse_parameters(expected_params, passed_params)
    params[COMMAND_KEY] = command
    return params
